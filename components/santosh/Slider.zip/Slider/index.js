import Slider from './Slider';

export default Slider;
